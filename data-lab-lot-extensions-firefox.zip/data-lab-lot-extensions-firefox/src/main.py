from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import re

keyword = 'Bitcoin'
options = webdriver.ChromeOptions()
options.add_argument('window-siize=1200x700')

service = Service(executable_path='./chrome-linux64/chrome')
driver = webdriver.Chrome(service=service, options=options)
driver.get('https://www.google.com/')

search_query = driver.find_element_by_name('q')
search_query.send_keys(keyword + ' wikipedia')
search_query.send_keys(Keys.RETURN)

wiki_url = driver.find_element_by_class_name("iUh30").text.replace(' > ', '/')
driver.get(wiki_url)

text = driver.find_element_by_xpath('//*[@id="mw-content-text"]/div[1]/p[2]').text
if text == '':
    text = driver.find_element_by_xpath('//*[@id="mw-content-text"]/div[1]/p[3]').text
text = re.sub("[\(\[].*?[\)\]]", "", text)
print(text)