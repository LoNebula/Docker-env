#イメージのビルドとコンテナの起動
docker build -t my-c-env .
docker run --rm -it -v "$PWD":/app my-c-env

♯コンテナ内でコンパイルと実行
gcc main.c -o main
./main